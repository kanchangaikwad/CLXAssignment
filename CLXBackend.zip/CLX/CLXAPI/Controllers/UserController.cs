﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using BAL;
using DAL;

namespace CLXAPI.Controllers
{
    [Route("api/User")] 
    [ApiController]
    public class UserController : ControllerBase
    {

        /// <summary>
        /// This method gives a call to fetch all users.
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetUsers")]
        public IEnumerable<Models.User> GetUsers()
        {
            var userInfo = new UserInfo();
            return userInfo.Users;
        }     


        /// <summary>
        /// This method gives a call to Add a new user.
        /// </summary>
        /// <param name="user">user object</param>
        /// <returns></returns>
        [Produces("application/json")]
        [Consumes("application/json")]
        [HttpPost("adduser")]
        public IActionResult AddUser(Models.User user)
        {
            try
            {
                if(user!=null)
                {
                    var userInfo = new UserInfo();
                    var existingUsers = userInfo.Users;

                    var results = existingUsers.Where(x => x.FirstName == user.FirstName && x.ContactNo == user.ContactNo);

                    if (results.ToList<Models.User>().Count == 0) //Record not present already
                    {
                        int index = existingUsers.Max(x => x.UserId) + 1;
                        user.UserId = index;
                        userInfo.AddUser(user);
                        return Ok(user);
                    }
                    else
                    {
                        return NotFound("User already exist");
                    }
                }
                else
                {
                    return BadRequest("Invalid input request.");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }           
        }
        
    }

}
