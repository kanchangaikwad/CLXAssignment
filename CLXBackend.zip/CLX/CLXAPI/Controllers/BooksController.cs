﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using BAL;

namespace CLXAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
     
        // GET: api/Books
        [HttpGet("GetBooks")]
        public IEnumerable<Models.Book> GetBooks()
        {
            var booksInfo = new BooksInfo();
            return booksInfo.Books;
        }


        [Produces("application/json")]
        [Consumes("application/json")]
        [HttpPut("loanbook")]
        public IActionResult LoanBook(Models.Book aBook)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var booksInfo = new BooksInfo();
            booksInfo.Loan(aBook);
            return Ok(aBook);
        }

        [Produces("application/json")]
        [Consumes("application/json")]
        [HttpPut("returnbook")]
        public IActionResult ReturnBook([FromBody] Models.Book aBook)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var booksInfo = new BooksInfo();
            booksInfo.Return(aBook);
            return Ok(aBook);
        }



        //// GET: api/Books/5
        //[HttpGet("BookInfo/{id}")]
        //public async Task<IActionResult> BookInfo([FromRoute] int id)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    var book = await _context.Book.FindAsync(id);

        //    if (book == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(book);
        //}

        //// PUT: api/Books/5
        //[HttpPut("PutBook/{id}")]
        //public async Task<IActionResult> PutBook([FromRoute] int id, [FromBody] Book book)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    if (id != book.BookId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(book).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!BookExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        //// POST: api/Books
        //[HttpPost]
        //public async Task<IActionResult> PostBook([FromBody] Book book)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    _context.Book.Add(book);
        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateException)
        //    {
        //        if (BookExists(book.BookId))
        //        {
        //            return new StatusCodeResult(StatusCodes.Status409Conflict);
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return CreatedAtAction("GetBook", new { id = book.BookId }, book);
        //}

        //// DELETE: api/Books/5
        //[HttpDelete("DeleteBook/{id}")]
        //public async Task<IActionResult> DeleteBook([FromRoute] int id)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    var book = await _context.Book.FindAsync(id);
        //    if (book == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.Book.Remove(book);
        //    await _context.SaveChangesAsync();

        //    return Ok(book);
        //}

        //private bool BookExists(int id)
        //{
        //    return _context.Book.Any(e => e.BookId == id);
        //}
    }
}