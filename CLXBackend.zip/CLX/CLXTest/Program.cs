﻿
using System;
using System.Linq;
using System.Text;
using static System.Console;

namespace CLXConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu();
        }

        private static void Menu()
        {

            Clear();
            WriteLine("CLX Console application : ");
            WriteLine("Select your choice.");
            WriteLine("1. Numner is 2's power");
            WriteLine("2. Reverse a string");
            WriteLine("3. Replicate a string");
            WriteLine("4. Print odd numbers.");
            string menu = ReadLine();
            switch (menu)
            {
                case "1":
                    IsPower2();
                    break;
                case "2":
                    ReverseString();
                    break;
                case "3":
                    Replicate();
                    break;
                case "4":
                    GetOddNumbers();
                    break;
                default:
                    WriteLine("Please enter correct choice.");
                    ReadLine();
                    Menu();
                    
                    break;
            }
        }

        private static void IsPower2()
        {
            try
            {
                WriteLine($"This program if a number is power of 2.");
                Write($"Enter a number : ");
                double number = Convert.ToDouble(ReadLine());
                bool result = true;
                if (number != 0)
                {
                    while (number != 1)
                    {
                        if (number % 2 != 0)
                        {
                            result = false;
                            break;
                        }
                        number = number / 2;
                    }
                }
                else
                {
                    result = false;
                }
                if (result)
                    WriteLine("The entered number is power of 2");
                else
                    WriteLine("The entered number is not a power of 2");

                Write("Do you want to try again (Y/N) : ");
                string YesNo = ReadLine();
                if (YesNo.ToUpper() == "Y")
                    IsPower2();

                FooterMenu();
                ReadLine();

            }
            catch (Exception ex)
            {
                WriteLine(ex.Message);
                FooterMenu();
                ReadLine();
            }
        }

        private static void FooterMenu()
        {
            WriteLine("\n");            
            WriteLine("Enter '1' : to Main menu");
            WriteLine("Enter '0' : to Exit");

            string subMenu = ReadLine();
            switch (subMenu)
            {
                case "0":
                    Environment.Exit(0);
                    break;
                case "1":
                    Menu();
                    break;
                default:
                    WriteLine("Please enter correct choice.");
                    FooterMenu();
                    break;
            }
        }

        private static void GetOddNumbers()
        {
            try
            {
                var numbers = Enumerable.Range(0, 100).ToList();
                var oddNumbers = numbers.Where(n => n % 2 != 0).ToList();
                WriteLine("Below are the odd numbers between 0 and 100");
                WriteLine($"{string.Join(" ", oddNumbers)}");

                FooterMenu();

                ReadLine();
            }
            catch (Exception ex)
            {
                WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Method to print reversed input string
        /// </summary>
        private static void ReverseString()
        {
            try
            {
                WriteLine($"This Method takes a input string and prints reversed.");
                Write($"Enter a string input : ");
                string strInput = ReadLine();
                WriteLine($"Entered string input is : {strInput}");

                char[] strInputArr = strInput.ToArray();
                Array.Reverse(strInputArr);
                WriteLine($"Reversed string is : {new string(strInputArr)}");

                Write("Do you want to try again (Y/N) : ");
                string YesNo = ReadLine();
                if (YesNo.ToUpper() == "Y")
                    ReverseString();

                FooterMenu();


                ReadLine();
            }
            catch (Exception ex)
            {
                WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Method to Replicate input string
        /// </summary>
        private static void Replicate()
        {
            try
            {
                WriteLine($"This Method replicates a input string for desired times");
                Write($"Enter a string input: ");
                string strInput = ReadLine();
                Write($"How many times do you want to replicate '{strInput}' ");
                int iCounter = Convert.ToInt32(ReadLine());
                StringBuilder sbResult = new StringBuilder();
                while (iCounter > 0)
                {
                    sbResult = sbResult.Append(strInput);
                    iCounter--;
                }
                WriteLine($"Replicated result : {sbResult.ToString()} ");

                Write("Do you want to try again (Y/N) : ");
                string YesNo = ReadLine();
                if (YesNo.ToUpper() == "Y")
                    Replicate();

                FooterMenu();


                ReadLine();

            }
            catch (Exception ex)
            {
                WriteLine(ex.Message);
            }

        }


    }
}
