﻿using System;
using System.Collections.Generic;

namespace DAL
{
    public partial class Transaction
    {
        public int TransId { get; set; }
        public int BookId { get; set; }
        public DateTime? BarrowDate { get; set; }
        public DateTime? ReturnDate { get; set; }

        public Book Book { get; set; }
    }
}
