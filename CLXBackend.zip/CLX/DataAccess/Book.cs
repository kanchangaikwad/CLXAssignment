﻿using System;
using System.Collections.Generic;

namespace DAL
{
    public partial class Book
    {
        public Book()
        {
            Transaction = new HashSet<Transaction>();
        }

        public int BookId { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Isbn { get; set; }
        public int? LoanedTo { get; set; }

        public ICollection<Transaction> Transaction { get; set; }
    }
}
