﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Models
{
   public interface IUser
    {
        IEnumerable<User> Users { get; }
        string AddUser(User user);
        string Update(User user);

        string Delete(User user);
    }
}
