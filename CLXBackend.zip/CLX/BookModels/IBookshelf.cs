﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Models
{
    public interface IBookshelf
    {
        IEnumerable<Book> Books { get; }
        bool Loan(Book book);
        bool Return(Book book);
    }
}
