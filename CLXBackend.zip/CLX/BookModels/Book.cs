﻿using System;

namespace Models
{
    public class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }
        public int? LoanedTo { get; set; }

        public int BookId { get; set; }
    }
}
