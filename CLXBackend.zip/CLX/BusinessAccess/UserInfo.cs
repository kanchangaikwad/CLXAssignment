﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using DAL;
using Models;

namespace BAL
{
    public class UserInfo : IUser
    {
        public IEnumerable<Models.User> Users => GetExistingUsers();

        private IEnumerable<Models.User> GetExistingUsers()
        {
            List<Models.User> users = new List<Models.User>();
            var _bookshelfContext = new BookshelfContext();
            foreach (var usr in _bookshelfContext.User)
            {
                users.Add(new Models.User
                {
                    UserId=usr.UserId,
                    FirstName=usr.FirstName,
                    LastName=usr.LastName,
                    ContactNo=usr.ContactNo,
                    Address=usr.Address
                    
                });
            }
            return users.AsEnumerable();
        }        



        public string AddUser(Models.User user)
        {
            var _bookshelfContext = new BookshelfContext();
            DAL.User dbUser = new DAL.User
            {
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                ContactNo = user.ContactNo,
                Address = user.Address
            };
            _bookshelfContext.User.Add(dbUser);
            _bookshelfContext.SaveChanges();

            return "OK";

        }

        public string Update(Models.User user)
        {   //TODO : User Updation call
            throw new NotImplementedException("To implement as enhancement.");
        }
        public string Delete(Models.User user)
        {   //TODO : User Deletion call
            throw new NotImplementedException("To implement as enhancement.");
        }
    }
}
