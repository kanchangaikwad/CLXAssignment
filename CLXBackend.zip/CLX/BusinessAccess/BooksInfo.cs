﻿using DAL;
using Models;
using System.Collections.Generic;
using System.Linq;

namespace BAL
{
    public class BooksInfo : IBookshelf
    {
        public IEnumerable<Models.Book> Books => BooksDataStore();

        private IEnumerable<Models.Book> BooksDataStore()
        {

            List<Models.Book> books = new List<Models.Book>();
            var _bookshelfContext = new BookshelfContext();
            foreach (var bk in _bookshelfContext.Book)
            {
                books.Add(new Models.Book
                {
                    Author = bk.Author,
                    ISBN = bk.Isbn,
                    LoanedTo = bk.LoanedTo,
                    Title = bk.Title,
                    BookId = bk.BookId
                });
            }
            return books.AsEnumerable();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="book"></param>
        /// <returns></returns>
        public bool Loan(Models.Book book)
        {
            return updateBookshelfForLoan(book);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="book"></param>
        /// <returns></returns>
        public bool Return(Models.Book book)
        {
            return updateBookshelfForReturn(book);
        }

        private bool updateBookshelfForReturn(Models.Book book)
        {
            bool isOk = true;
            var _bookshelfContext = new BookshelfContext();
            int bookId = book.BookId;
            var existingBook = _bookshelfContext.Book.Where(b => b.BookId == bookId)
                                                    .FirstOrDefault();


            if (existingBook != null)
            {
                existingBook.LoanedTo = book.LoanedTo;
                _bookshelfContext.SaveChanges();
            }
            else
            {
                isOk = false;
            }
            return isOk;
        }
        private bool updateBookshelfForLoan(Models.Book book)
        {
            bool isOk = true;
            var _bookshelfContext = new BookshelfContext();
            int bookId = book.BookId;
            var existingBook = _bookshelfContext.Book.Where(b => b.BookId == bookId)
                                                    .FirstOrDefault();

            if (existingBook != null)
            {
                if (existingBook.LoanedTo > 0)
                {
                    isOk = false;
                }
                else
                {
                    existingBook.LoanedTo = book.LoanedTo;
                    _bookshelfContext.SaveChanges();
                }
            }
            else
            {
                isOk = false;
            }
            return isOk;
        }

    }
}
