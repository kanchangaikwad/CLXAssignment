import { User } from './user';







export const Users: User[] = [

    { userId: 1, firstName: 'Kanchan', lastName: 'Gaikwad', contactNo: '0767579916', address: 'sweden' },
    { userId: 2, firstName: 'Magnus', lastName: 'Boris', contactNo: '0767579100', address: 'sweden' }
];
