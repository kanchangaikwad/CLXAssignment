

import { Component, OnInit, Input } from '@angular/core';
import { Book } from '../book';
import { CartService } from '../cart.service';
import { BookService } from '../book.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  selectedBooks: Book [];

  constructor(private bookService: BookService,
              private cartService: CartService) {
    this.selectedBooks = cartService.selectedBooks;
   }

  getSelectedBooks() {
    return this.selectedBooks;
  }

  BookReturn(book) {
    this.bookService.ReturnBook(book);
    this.cartService.ReturnBookfromCart(book);
  }

  ngOnInit() {

    this.getSelectedBooks();
  }

}
