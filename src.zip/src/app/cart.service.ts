import { Injectable } from '@angular/core';
import { Book } from './book';
import { BookService } from './book.service';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private bookService: BookService,
              private userService: UserService ) {
                  console.log(JSON.stringify(bookService.BOOKS));
                  this.selectedBooks = bookService.BOOKS.filter(b => b.loanedTo == userService.currentUser);
            }

  selectedBooks: Book[] = [];
  AddBookToCart(book: Book, userId: number): void {
    console.log('Title :' + book.title);
    if ( (book.loanedTo !== userId) && (!this.selectedBooks.some((item) => item.bookId == book.bookId))  ) {
          book.loanedTo = userId;
          this.selectedBooks.push(book);
          console.log(this.selectedBooks.length);
    } else {
      alert('Already added in a cart.');
    }
  }

  ReturnBookfromCart(book: Book): void {
    const index: number = this.selectedBooks.indexOf(book);
    alert(book);
    if (index !== -1) {
        this.selectedBooks.splice(index, 1);
    }
  }

}
