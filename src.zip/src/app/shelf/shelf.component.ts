import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { CartService } from '../cart.service';
import { BookService } from '../book.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-shelf',
  templateUrl: './shelf.component.html',
  styleUrls: ['./shelf.component.css']
})
export class ShelfComponent implements OnInit {
books: Book[];
selectedBooks: Book[] = [];
selectedUser: string;
selectedUserId: number;


  constructor(
              private bookService: BookService,
              private cartService: CartService,
              private userService: UserService) { }

  LoanBook(book, selectedUserId) {   
    this.bookService.LoanBook(book, selectedUserId);
    this.cartService.AddBookToCart(book, selectedUserId);
  }

  ngOnInit() {
    this.getBooks();
    this.selectedUserId = this.userService.currentUser;
    this.selectedUser = this.userService.getSelectedUserName(this.selectedUserId);
  }

  getBooks() {
    this.bookService.getBooks()
        .subscribe(books => this.books = books);
  }

}
