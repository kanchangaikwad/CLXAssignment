import {Book} from './book';





export const Books: Book[] = [
    // {bookId: 11, ISBN: 'ABCD-1234', Title: '.Net Core', LoanedTo: 2},
    // {bookId: 11, ISBN: 'PQRS-1357', Title: '.Net Core for beginers', LoanedTo: 5},
    // {bookId: 11, ISBN: 'PQRS-2468', Title: '.Net Core Advanced', LoanedTo: 7},
    // {bookId: 11, ISBN: 'ABCD-4321', Title: 'ASP.net in 7 days', LoanedTo: 8},
    // {bookId: 11, ISBN: 'ABCD-7531', Title: 'Angular 6', LoanedTo: 9},
    // {bookId: 11, ISBN: 'PQRS-1123', Title: 'React Redux', LoanedTo: 3}
];

