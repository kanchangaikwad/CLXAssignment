export class Book {
bookId: number;
title: string;
isbn: string;
loanedTo: number;
}

