export class User {
    userId: number;
    firstName: string;
    lastName: string;
    contactNo: string;
    address: string;
    }
