import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { BookService } from '../book.service';

@Component({
    selector: 'app-home',
    templateUrl : './Home.component.html',
    styleUrls: ['./Home.component.css']
})

export class HomeComponent implements OnInit {
   
    constructor(private bookService: BookService) { }

    ngOnInit() {
     
    }

    // getbooks(): void {
    //     this.bookService.getBooks()
    //         .subscribe(books => this.books = books);
    // }
}
