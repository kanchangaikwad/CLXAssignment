import { Injectable } from '@angular/core';
import { Book } from './book';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor() { }
  selectedBooks:Book[]=[];
  onSelect(book: Book):void{
    alert(book.Title);
    this.selectedBooks.push(book);
    alert(this.selectedBooks.length);
  }

}
