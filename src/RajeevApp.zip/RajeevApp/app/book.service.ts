import { Injectable } from '@angular/core';
import { Book } from './book';
import { Books } from './mockBooks';
import { Observable, of } from 'rxjs';
import { MessageService } from './message.service';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import {map, catchError, tap } from 'rxjs/operators'; 


@Injectable({
  providedIn: 'root'
})
export class BookService {
  constructor(private messageService: MessageService, private http: HttpClient) { }
  // getBooks(): Observable<Book[]> {
  //   this.messageService.add('BookService: Available Books');
  // //   const url = 'https://localhost:44370/api/books/GetBooks';
  // //  const result = this.http.get<Book[]>(url);
  // //   return result;

  // return of(Books);
  // }

  getBooks() : Observable<Book[]> {
    console.log("h i ");
    // this.messageService.add('BookService: Available Books');
    const url = 'http://localhost:10642/api/books/BooksInfo';
    
    const data = this.http.get<Book[]>(url);
    console.log(data);
    return of(Books);

    // const url = 'http://localhost:10642/api/books/BooksInfo';
    
    // //return this.http.get<Book[]>(url);
    // return this.http.get<Book[]>(url).pipe( 
    //   tap(data => console.log(JSON.stringify(data))), 
    //   catchError(this.handleError)
    //   );

  }

  private handleError(err: HttpErrorResponse){
    
  }

}
