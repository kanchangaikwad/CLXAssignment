import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { CartService } from '../cart.service';
import { BookService } from '../book.service';

@Component({
  selector: 'app-shelf',
  templateUrl: './shelf.component.html',
  styleUrls: ['./shelf.component.css']
  
})
export class ShelfComponent implements OnInit {
books : Book[];
selectedBooks:Book[]=[];

  constructor(private bookService: BookService, private cartService : CartService) { }
  // onSelect(book: Book):void{
  //   alert(book.Title);
  //   this.selectedBooks.push(book);
  //   alert(this.selectedBooks.length);
  // }
  onSelect(book){
    this.cartService.onSelect(book);
  }
 
  ngOnInit() {
    this.getBooks();
  }

  getBooks(){
    this.bookService.getBooks()
        .subscribe(books=>this.books = books);
  }

}
