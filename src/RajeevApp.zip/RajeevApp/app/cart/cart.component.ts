

import { Component, OnInit, Input } from '@angular/core';
import { Book } from '../book';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  selectedBooks:Book[];
 
  constructor(private cartService:CartService) {
    this.selectedBooks=cartService.selectedBooks;
   }

  getSelectedBooks()
  {
   
    return this.selectedBooks;
  }

  ngOnInit() {
   
    this.getSelectedBooks();
  }

}
