export class Book {
BookId: number;
Title: string;
ISBN: string;
LoanedTo: number;
}

